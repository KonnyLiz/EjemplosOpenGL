#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
GLfloat plano_s[4] = {1, 0, 0, 0};// s=x
GLfloat plano_v[4] = {0, 1, 0, 0};// v=y
GLuint texture[1];
int rotate_x=0;

double rotate_y=0;

double rotate_z=0;

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;
//Funcion que dibuja el cesped
void plano(void)
{
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	 glLoadIdentity();
    // Rotar en el eje X,Y y Z
    glRotatef( rotate_x, 1.0, 0.0, 0.0 );
    glRotatef( rotate_y, 0.0, 1.0, 0.0 );
    glRotatef( rotate_z, 0.0, 0.0, 1.0 );
    glTranslatef(X, Y, Z); 	// Transladar en los 3 ejes
    // Otras transformaciones
    glScalef(scale, scale, scale);
    
  //Definicion de texturas
  texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
  (
      "22911.jpg",
      SOIL_LOAD_AUTO,
      SOIL_CREATE_NEW_ID,
      SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
  );
  glEnable(GL_TEXTURE_2D);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  // allocate a texture name
  glBindTexture(GL_TEXTURE_2D, texture[0]);
  glBegin(GL_QUADS);
  glTexCoord2f(10,10);
  glVertex3f(-50.0f,-50.0f,0.0f);
  glTexCoord2f(0,10);
  glVertex3f(-50.0f,50.0f,0.0f);
  glTexCoord2f(10,0);
  glVertex3f( 50.0f,50.0f,0.0f);
  glTexCoord2f(0,0);
  glVertex3f( 50.0f,-50.0f,0.0f);
  glEnd();
}
void dibujando(void)
{
  //Esfera
  glTranslatef(-5.0f, 0.0f,0.0f);
  glutSolidSphere(3,50,50);
  glPopMatrix();
  glPushMatrix();

  //Cubo
  glTranslatef(-8.0f, 0.0f, -7.0f);
  glutSolidCube(3);
  glPopMatrix();
  glPushMatrix();

  //Dona
  //glColor3f(0.0, 1.0, 0.0);
  glTranslatef(-15.0f, 0.0f, 0.0f);
  glutSolidTorus(0.5,3,10,10);
  glPopMatrix();
  glPushMatrix();

  //Icosahedro
  glTranslatef(-25.0f, 0.0f, -7.0f);
  glScalef(2,2,2);
  glutSolidIcosahedron();
  glPopMatrix();
  glPushMatrix();

  //Cono
  glTranslatef(7.0f, 0.0f, -7.0f);
  glScalef(2,2,2);
  glutSolidCone(1,2,20,20);
  glPopMatrix();
  glPushMatrix();

  //Tetera
  glTranslatef(15.0f, 0.0f, 0.0f);
  glScalef(2,2,2);
  glutSolidTeapot(1);
  glPopMatrix();
  glPushMatrix();

  //Tetaedro
  glTranslatef(20.0f, 0.0f, -7.0f);
  glScalef(2,2,2);
  glutSolidTetrahedron();
  glPopMatrix();
  glPushMatrix();

  //Octaedro
  glTranslatef(25.0f, 0.0f, 0.0f);
  glScalef(2,2,2);
  glutSolidOctahedron();
  glPopMatrix();
  glPushMatrix();

  //Docecaedro
  glTranslatef(30.0f, 0.0f, -7.0f);
  glutSolidDodecahedron();
  glPopMatrix();
  glPushMatrix();

}
void display(void)
{
    //  Borrar pantalla y Z-buffer

   
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    plano();
    // Resetear transformaciones
    glLoadIdentity();
    texture[1] = SOIL_load_OGL_texture // cargamos la imagen
   (
       "textura.jpg",
       SOIL_LOAD_AUTO,
       SOIL_CREATE_NEW_ID,
       SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
   );
    //Definicion de texturas
    glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexGeni (GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGenfv (GL_S, GL_OBJECT_PLANE, plano_s);
    glEnable (GL_TEXTURE_GEN_S);
    glTexGeni (GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGenfv (GL_T, GL_OBJECT_PLANE, plano_v);
    glEnable (GL_TEXTURE_GEN_T);
    glTexGeni (GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
    glBindTexture(GL_TEXTURE_2D, texture[1]);
    dibujando();
    
    glEnd();
    glFlush();

}

void specialKeys( int key, int x, int y )
{

    //  Flecha derecha: aumentar rotación 7 grados
    if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;

    //  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
    //  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
    //  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
    //  Tecla especial F2 : rotación en eje Z positivo 7 grados
    else if (key == GLUT_KEY_F2)
        rotate_z += 7;
    //  Tecla especial F2 : rotación en eje Z negativo 7 grados
    else if (key == GLUT_KEY_F2)
        rotate_z -= 7;

    //  Solicitar actualización de visualización
    glutPostRedisplay();

}

void init(void)
{
	glShadeModel(GL_FLAT);
  glOrtho(-100.0,100.0,-100.0,100.0,-100.0,100.0);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void reshape(int w, int h)
{
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0f, (GLfloat)w/(GLfloat)h, 0.0f, 1.0f);
	gluLookAt(0.0,-20.0,20.0, 
			  0.0,0.0,0.0,
			  0.0,1.0,0.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (800, 700);//tamaño de la ventana
    glutInitWindowPosition (300, 100);//posicion de la ventana en la pantalla
    glutCreateWindow ("Sombra sin sombra");//nombre de la ventana
    init ();
    glutDisplayFunc(display);
    glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
